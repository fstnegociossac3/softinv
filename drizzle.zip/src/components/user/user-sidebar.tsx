"use client";

import Link from "next/link";

import { usePathname } from "next/navigation";

import {
  Building2,
  CarFront,
  LayoutDashboard,
  LogOut,
  Package,
  Upload,
  ChartNoAxesCombined,
} from "lucide-react";

import { Button } from "@/components/ui/button";

import { cn } from "@/lib/utils";

import { logoutAction } from "@/server/actions/auth.actions";

type UserSidebarProps = {
  fullName: string;

  companyName: string;

  className?: string;

  onNavigate?: () => void;
};

const userNavigation = [
  {
    title: "Dashboard",

    href: "/dashboard",

    icon: LayoutDashboard,
  },

  {
    title: "Importaciones",

    href: "/imports",

    icon: Upload,
  },

  {
    title: "Inventario",

    href: "/inventory",

    icon: Package,
  },
  {
    title: "Análisis IRI",

    href: "/iri",

    icon: ChartNoAxesCombined,
  },
];

function getInitials(name: string) {
  return name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part.charAt(0))
    .join("")
    .toUpperCase();
}

export function UserSidebar({
  fullName,
  companyName,
  className,
  onNavigate,
}: UserSidebarProps) {
  const pathname = usePathname();

  return (
    <aside
      className={cn(
        "flex h-full w-72 flex-col border-r border-slate-200 bg-white",
        className,
      )}
    >
      {/* LOGO */}

      <div className="flex h-20 items-center border-b border-slate-200 px-6">
        <Link
          href="/dashboard"
          onClick={onNavigate}
          className="flex items-center gap-3"
        >
          <div className="flex size-11 items-center justify-center rounded-xl bg-[#12365A] shadow-sm">
            <CarFront className="size-5 text-white" />
          </div>

          <div>
            <p className="font-bold tracking-tight text-slate-900">
              RecuperaStock
              <span className="text-red-600"> AI</span>
            </p>

            <p className="text-[10px] font-medium uppercase tracking-[0.18em] text-slate-400">
              Plataforma empresarial
            </p>
          </div>
        </Link>
      </div>

      {/* EMPRESA */}

      <div className="px-4 pt-5">
        <div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
          <div className="flex items-center gap-3">
            <div className="flex size-9 items-center justify-center rounded-lg bg-[#12365A]/10">
              <Building2 className="size-4 text-[#12365A]" />
            </div>

            <div className="min-w-0">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                Empresa
              </p>

              <p className="truncate text-sm font-semibold text-slate-800">
                {companyName}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* NAVEGACIÓN */}

      <div className="flex-1 overflow-y-auto px-4 py-6">
        <p className="mb-3 px-3 text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-400">
          Menú principal
        </p>

        <nav className="space-y-1">
          {userNavigation.map((item) => {
            const Icon = item.icon;

            const active =
              pathname === item.href || pathname.startsWith(`${item.href}/`);

            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={onNavigate}
                className={cn(
                  "group flex h-11 items-center gap-3 rounded-xl px-3 text-sm font-medium transition-all",

                  active
                    ? "bg-[#12365A] text-white shadow-sm"
                    : "text-slate-600 hover:bg-slate-100 hover:text-slate-900",
                )}
              >
                <Icon
                  className={cn(
                    "size-5",

                    active
                      ? "text-white"
                      : "text-slate-400 group-hover:text-[#12365A]",
                  )}
                />

                {item.title}
              </Link>
            );
          })}
        </nav>
      </div>

      {/* USUARIO */}

      <div className="border-t border-slate-200 p-4">
        <div className="rounded-xl bg-slate-50 p-3">
          <div className="flex items-center gap-3">
            <div className="flex size-10 shrink-0 items-center justify-center rounded-full bg-[#12365A]/10 text-sm font-bold text-[#12365A]">
              {getInitials(fullName)}
            </div>

            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold text-slate-900">
                {fullName}
              </p>

              <p className="text-xs text-slate-500">Usuario</p>
            </div>
          </div>

          <form action={logoutAction} className="mt-3">
            <Button
              type="submit"
              variant="ghost"
              className="w-full justify-start text-slate-600 hover:text-red-600"
            >
              <LogOut className="mr-2 size-4" />
              Cerrar sesión
            </Button>
          </form>
        </div>
      </div>
    </aside>
  );
}
