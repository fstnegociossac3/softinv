import Link from "next/link";

import { Plus } from "lucide-react";

import { buttonVariants } from "@/components/ui/button";

import { PageHeader } from "@/components/shared/page-header";

import { ImportFilters } from "@/components/imports/import-filters";
import { ImportTable } from "@/components/imports/import-table";

import { requireAuth } from "@/server/services/auth.service";

import { getInventoryImports } from "@/server/queries/inventory-import.queries";

import { getCompanies } from "@/server/queries/company.queries";

type ImportStatus =
  | "uploaded"
  | "validating"
  | "ready"
  | "processed"
  | "failed";

type ImportsPageProps = {
  searchParams: Promise<{
    search?: string;
    status?: ImportStatus;
    companyId?: string;
    page?: string;
  }>;
};

export default async function ImportsPage({ searchParams }: ImportsPageProps) {
  const auth = await requireAuth();

  const params = await searchParams;

  const page = Math.max(Number(params.page) || 1, 1);

  const result = await getInventoryImports({
    search: params.search,
    status: params.status,
    companyId: auth.profile.role === "admin" ? params.companyId : undefined,
    page,
    pageSize: 20,
  });

  const companyResult =
    auth.profile.role === "admin"
      ? await getCompanies({
          page: 1,
          pageSize: 100,
        })
      : null;

  const companies = companyResult?.data ?? [];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Importaciones"
        description="Carga, valida y revisa los inventarios importados."
        actions={
          <Link href="/imports/new" className={buttonVariants()}>
            <Plus className="mr-2 size-4" />
            Nueva importación
          </Link>
        }
      />

      <ImportFilters
        companies={companies}
        showCompanyFilter={auth.profile.role === "admin"}
      />

      <ImportTable
        imports={result.data}
        companies={companies}
        currentCompanyName={auth.company?.name ?? null}
        total={result.total}
        page={result.page}
        pageSize={result.pageSize}
      />
    </div>
  );
}
